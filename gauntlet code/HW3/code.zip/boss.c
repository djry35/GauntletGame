#include "game.h"

//Knock yourself out boys and girls. 

Boss* loadBoss()
{

}

ActionNode* addActionToList(ActionNode* front, ActionNode* newAction)
{

}

DecisionTreeNode* addNodeToTree(DecisionTreeNode* root, DecisionTreeNode* newNode)
{

}

ActionNode* fetchNewList(Boss* boss, DecisionTreeNode* root)
{

}

void freeBossTree(DecisionTreeNode* root)
{

}

void freeActionListInNode(ActionNode* head)
{

}
