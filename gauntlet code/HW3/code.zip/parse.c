#include "game.h"

//If you haven't knocked yourself out in boss.c, do it here.
//Otherwise, knock yourself out again. 

void ParseShieldInfo(Shield* s, FILE* fp)
{

}

void ParseSwordInfo(Sword* s, FILE* fp)
{

}
